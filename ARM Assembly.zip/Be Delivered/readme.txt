Name: Bijan Ghasemi Afshar (100125463)

Helps received: Got some insight about the basic meaning of some instructions.

Times consumed by the ?b programs:
	2a:	494.985059s
	2b:	426.991470s
	2c:	151.280016s
	2d:	141.133298s